(function ($) {
    $.ajax({
        type: "Post",
        url: "/umbraco/surface/GetLoginScreenMedia/GetLoginScreenMedia",
        success: function (result) {
            $.ajax({
                type: "Post",
                url: "/umbraco/surface/GetLoginScreenMedia/UpdatePackageMeanifest",
                success: function (result1) {
                }
            });
        }
    });
})(jQuery);