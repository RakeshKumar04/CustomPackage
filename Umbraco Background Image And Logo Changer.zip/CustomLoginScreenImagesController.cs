﻿using System;
using System.IO;
using Umbraco.Web.Mvc;

namespace App_Code.CustomLoginScreenImagesController
{
    public class GetLoginScreenMediaController : SurfaceController
    {
        public string GetLoginScreenMedia()
        {
            try
            {
                var contentService = Services.ContentService;
                var resultNode = contentService.GetByLevel(1);
                if (resultNode != null)
                {
                    foreach (var item in resultNode)
                    {
                        if (item.ContentType.Alias == "umbracoLoginScreenSetting")
                        {
                            var bg = item.GetValue("umbracoLoginScreenBackgroundImage");
                            var lg = item.GetValue("umbracoLoginScreenLogoImage");
                            
                            string Path1 = Server.MapPath(@"\App_Plugins\CustomLoginScreenImages\css\");
                            string[] filePaths1 = Directory.GetFiles(Path1);
                            var cssFile = filePaths1[0];
                            string css = "";

                            if(lg != null)
                            {
                                css += ".login-overlay__logo {background:url('" + Umbraco.Media(lg).Url + "') no-repeat !important;width: 30px;height: 30px;background-size: cover !important;} .login-overlay__logo img {display:none;}";
                            }

                            if (bg != null)
                            {
                                css += ".login-overlay__background-image { background:url('" + Umbraco.Media(bg).Url + "') !important;background-position: 50% !important;background-repeat: no-repeat !important;background-size: cover !important;opacity:0.5 !important;}";
                            }
                            System.IO.File.WriteAllText(cssFile, css);

                            break;
                        }
                    }
                }
                return "CSS update successfully :)";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string UpdatePackageMeanifest()
        {
            try
            {
                string Path = Server.MapPath(@"\App_Plugins\CustomLoginScreenImages\");
                string[] filePaths = Directory.GetFiles(Path);
                var packageManifestFile = filePaths[1];

                var numberFile = filePaths[0];
                string numberText = System.IO.File.ReadAllText(numberFile);
                double number = double.Parse(numberText) + 0.1;

                if(number == 10)
                {
                    number = 1;
                }

                string content = "{propertyEditors: [],parameterEditors:[],javascript: ['~/App_Plugins/CustomLoginScreenImages/js/login.js?v=" + number + "'],css: ['~/App_Plugins/CustomLoginScreenImages/css/style.css?v=" + number + "']}";

                System.IO.File.WriteAllText(packageManifestFile, content);
                System.IO.File.WriteAllText(numberFile, number.ToString());

                System.Threading.Thread.Sleep(3000);

                return "package.manifest update successfully :)";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }
    }
}