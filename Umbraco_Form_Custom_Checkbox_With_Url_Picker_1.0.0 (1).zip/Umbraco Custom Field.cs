﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Umbraco.Forms.Core.Enums;
using Umbraco.Forms.Core.Models;

namespace UmbracoCustomField
{
    public class UmbracoCustomField : Umbraco.Forms.Core.FieldType
    {
        public UmbracoCustomField()
        {
            this.Id = new Guid("5C754DCE-8E85-4C7A-9CD6-B35441D44691");
            this.Name = "CheckboxWithUrl"; //this will also be the name of the view
            this.Description = "Checkbox with specific url";
            this.Icon = "icon-checkbox";
            this.DataType = FieldDataType.String;
        }
        //extra settings
        [Umbraco.Forms.Core.Attributes.Setting("Url", PreValues = "", Description = "Please Enter your url. Ex: https://example.com", View = "TextField")]
        public string Policy { get; set; }
        //custom value
        public override IEnumerable<object> ProcessSubmittedValue(Field field, IEnumerable<object> postedValues, HttpContextBase context)
        {
            List<object> returnValue = new List<object>();
            if (postedValues.ToList().Count > 0)
            {
                returnValue.Add("true");
            }
            else
            {
                returnValue.Add("false");
            }
            return returnValue;
        }
    }
}